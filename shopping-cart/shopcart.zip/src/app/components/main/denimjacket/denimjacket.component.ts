import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-denimjacket',
  templateUrl: './denimjacket.component.html',
  styleUrls: ['./denimjacket.component.css']
})
export class DenimjacketComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
