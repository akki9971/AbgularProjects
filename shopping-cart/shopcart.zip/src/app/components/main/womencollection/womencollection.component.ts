import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-womencollection',
  templateUrl: './womencollection.component.html',
  styleUrls: ['./womencollection.component.css']
})
export class WomencollectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
