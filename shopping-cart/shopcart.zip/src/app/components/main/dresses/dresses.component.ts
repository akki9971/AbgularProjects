import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dresses',
  templateUrl: './dresses.component.html',
  styleUrls: ['./dresses.component.css']
})
export class DressesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
