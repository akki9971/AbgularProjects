import { Productdetail } from './productdetail';

describe('Productdetail', () => {
  it('should create an instance', () => {
    expect(new Productdetail()).toBeTruthy();
  });
});
